package Assistedlesson2;

public class methods {
		  public int addNumbers(int x, int y) {
		    int sum = x + y;
		    return sum;
		  }
		  public static void main(String[] args) {
		    int a = 65;
		    int b = 24;
		    methods obj = new methods();
		    int result = obj.addNumbers(a, b);
		    System.out.println("Sum is: " + result);
		  }
		}


