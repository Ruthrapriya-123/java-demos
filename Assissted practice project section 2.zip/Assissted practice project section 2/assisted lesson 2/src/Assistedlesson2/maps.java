package Assistedlesson2;
import java.util.*;
public class maps {
	
	

		public static void main(String[] args) {
			// map
			
			//Hashmap
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"sara");    
		      hm.put(2,"deepa");    
		      hm.put(3,"candy");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(@SuppressWarnings("rawtypes") Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"jan");  
		      ht.put(5,"Rosi");  
		      ht.put(6,"Jeevi");  
		      ht.put(7,"John");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(@SuppressWarnings("rawtypes") Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"ruthu");    
		      map.put(9,"abi");    
		      map.put(10,"supi");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(@SuppressWarnings("rawtypes") Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}


