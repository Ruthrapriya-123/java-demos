package Assistedlesson2;

public class constructors {
	
	
		  private String name;
		  constructors() {
		    System.out.println("Constructor Called:");
		    name = "Simplilearn";
		   
		  }
		  public static void main(String[] args) {
		    constructors object = new constructors();
		    System.out.println("The name is " + object.name);
		    
		  }
		}
	
	

